$ErrorActionPreference = "Stop"
$RootDirectory = "$PSScriptRoot"
$DeployDirectory = "$RootDirectory\..\"
$ResourcesDirectory = "$DeployDirectory\..\src\main\resources\"

."$RootDirectory\assert.ps1"
."$ResourcesDirectory\get-functionapp-name.ps1"
."$DeployDirectory\get-resource-group-name.ps1"
."$DeployDirectory\get-resource-group-location.ps1"
."$DeployDirectory\create-resource-group-if-not-exists.ps1"

$subscriptionId = "79fa1051-b3e0-4da4-bfbe-044dd728427f"
$azureAccountName = $env:AZURE_ACCOUNT_NAME
$azureAccountPassword = $env:AZURE_ACCOUNT_PASSWORD
$azurePasswordSecure = ConvertTo-SecureString $azureAccountPassword -AsPlainText -Force
$azureCredentials = New-Object System.Management.Automation.PSCredential($AzureAccountName, $AzurePasswordSecure)
Add-AzureRmAccount -Credential $azureCredentials -SubscriptionID $subscriptionId
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

# make sure that there is an storage account

$azureAccountName = $env:AZURE_ACCOUNT_NAME
$azureAccountPassword = $env:AZURE_ACCOUNT_PASSWORD
$dataDirectory = "$RootDirectory\data"
$parametersFilePath = "$dataDirectory\script-parameters\valid-deploy.json"
$deploymentScriptParameters = (ConvertFrom-Json -InputObject (Gc $parametersFilePath -Raw))
$armParametersFilePath = ("{0}\arm-parameters\{1}" -f $dataDirectory, $deploymentScriptParameters.armParametersFileName)
$resourceGroupName = Get-Resource-Group-Name -RootDirectory $RootDirectory

$armDeploymentParameters = (ConvertFrom-Json -InputObject (Gc  "$armParametersFilePath" -Raw)).parameters
$storageAccountName =  $armDeploymentParameters.storageName.value
$storageAccountLocation =  $armDeploymentParameters.location.value

$existingStorageAccountMeasure = Find-AzureRmResource -ResourceType "Microsoft.Storage/storageAccounts" -ResourceNameEquals "$storageAccountName" | measure
$existingStorageAccountCount = $existingStorageAccountMeasure.Count

if($existingStorageAccountCount -eq 0)
{
    New-AzureRmStorageAccount -ResourceGroupName "$resourceGroupName" -AccountName "$storageAccountName" -Location "$storageAccountLocation" -Type "Standard_LRS"
}

# make sure there is an unique marker file in the storage account
# maybe: store storage account metadata, e.g. creation time ?

$storageAccount = Get-AzureRmStorageAccount -ResourceGroupName "$resourceGroupName" -AccountName "$storageAccountName"
$storageAccountCreationTime = $storageAccount.CreationTime

# run the deployment

function Run-Deployment 
{
    . "$ResourcesDirectory\deploy.ps1" -azureAccountName $args[0] -azureAccountPassword $args[1] -armParametersFilePath $args[2]-functionCodeArchivePath $args[3] -azureSubscriptionId $args[4] -resourceGroupName $args[5] 
}

$dataDirectory = "$RootDirectory\data"

$azureAccountName = $env:AZURE_ACCOUNT_NAME
$azureAccountPassword = $env:AZURE_ACCOUNT_PASSWORD
$azurePasswordSecure = ConvertTo-SecureString $azureAccountPassword -AsPlainText -Force
$azureCredentials = New-Object System.Management.Automation.PSCredential($AzureAccountName, $AzurePasswordSecure)
$parametersFilePath = "$dataDirectory\script-parameters\valid-deploy.json"
$deploymentScriptParameters = (ConvertFrom-Json -InputObject (Gc $parametersFilePath -Raw))
$azureSubscriptionId = $deploymentScriptParameters.subscriptionID

Add-AzureRmAccount -Credential $azureCredentials -SubscriptionID $azureSubscriptionId

$armParametersFilePath = ("{0}\arm-parameters\{1}" -f $dataDirectory, $deploymentScriptParameters.armParametersFileName)
$functionappName = Get-Functionapp-Name -armParametersFilePath $armParametersFilePath

$functionCodeArchivePath = "$dataDirectory\$functionappName.zip"

$resourceGroupName = Get-Resource-Group-Name -RootDirectory $RootDirectory
$resourceGroupLocation = Get-Resource-Group-Location -RootDirectory $RootDirectory

Create-Resource-Group-If-Not-Exists -resourceGroupName $resourceGroupName -resourceGroupLocation $resourceGroupLocation

Run-Deployment $azureAccountName $azureAccountPassword $armParametersFilePath $functionCodeArchivePath $azureSubscriptionId $resourceGroupName

# assert no marker file in the storage account
# maybe: assert metadata change

$storageAccountAfterDeployment = Get-AzureRmStorageAccount -ResourceGroupName "$resourceGroupName" -AccountName "$storageAccountName"
$storageAccountAfterDeploymentCreationTime = $storageAccountAfterDeployment.CreationTime

Write-Host $storageAccountCreationTime
Write-Host $storageAccountAfterDeploymentCreationTime

AssertThat { $storageAccountAfterDeploymentCreationTime -gt $storageAccountCreationTime }

exit 0