Function AssertThat
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory = $true, Position = 1, ValueFromPipeline = $true)]
		[ScriptBlock]$Action
    )
    $actionResult = & $Action
    
    if($actionResult -ne $True)
    {
        Write-Host "Assertion $Action failed." -foregroundColor "Red"
        exit 1
    }
}