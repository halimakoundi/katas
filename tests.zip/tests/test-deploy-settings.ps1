$ErrorActionPreference = "Stop"
$RootDirectory = "$PSScriptRoot"
$DeployDirectory = "$RootDirectory\.."
$ResourcesDirectory = "$DeployDirectory\..\src\main\resources\"

# includes
."$RootDirectory\assert.ps1"
."$DeployDirectory\get-resource-group-name.ps1"
."$DeployDirectory\get-resource-group-location.ps1"
."$DeployDirectory\create-resource-group-if-not-exists.ps1"
."$ResourcesDirectory\get-functionapp-name.ps1"

function Settings-Are-Equal
{
    Param
    (
        [Parameter(Mandatory=$True)]
        [object]$keysTocheck,

        [Parameter(Mandatory=$True)]
        [object]$expectedValues,

        [Parameter(Mandatory=$True)]
        [object]$actualSettings
    )
    foreach($key in $keysTocheck) { 
        $expectedValue = $expectedValues."$key".value
        $actualValue = $actualSettings."$key"
        if( $expectedValue -ne $actualValue )
        {
            Write-Host "Expected '$expectedValue' for '$key', but it was '$actualValue'" -foregroundColor "Red"
            return $False
        }
    }

    return $True
}

function Run-Deployment 
{
    . "$ResourcesDirectory\deploy.ps1" -azureAccountName $args[0] -azureAccountPassword $args[1] -armParametersFilePath $args[2]-functionCodeArchivePath $args[3] -azureSubscriptionId $args[4] -resourceGroupName $args[5] 
}

$dataDirectory = "$RootDirectory\data"

$azureAccountName = $env:AZURE_ACCOUNT_NAME
$azureAccountPassword = $env:AZURE_ACCOUNT_PASSWORD
$azurePasswordSecure = ConvertTo-SecureString $azureAccountPassword -AsPlainText -Force
$azureCredentials = New-Object System.Management.Automation.PSCredential($AzureAccountName, $AzurePasswordSecure)
$parametersFilePath = "$dataDirectory\script-parameters\valid-deploy.json"
$deploymentScriptParameters = (ConvertFrom-Json -InputObject (Gc $parametersFilePath -Raw))
$azureSubscriptionId = $deploymentScriptParameters.subscriptionID

Add-AzureRmAccount -Credential $azureCredentials -SubscriptionID $azureSubscriptionId

$armParametersFilePath = ("{0}\arm-parameters\{1}" -f $dataDirectory, $deploymentScriptParameters.armParametersFileName)
$functionappName = Get-Functionapp-Name -armParametersFilePath $armParametersFilePath

$functionCodeArchivePath = "$dataDirectory\$functionappName.zip"

$resourceGroupName = Get-Resource-Group-Name -RootDirectory $RootDirectory
$resourceGroupLocation = Get-Resource-Group-Location -RootDirectory $RootDirectory

Create-Resource-Group-If-Not-Exists -resourceGroupName $resourceGroupName -resourceGroupLocation $resourceGroupLocation

Run-Deployment $azureAccountName $azureAccountPassword $armParametersFilePath $functionCodeArchivePath $azureSubscriptionId $resourceGroupName

$armDeploymentParameters = (ConvertFrom-Json -InputObject (Gc  "$armParametersFilePath" -Raw)).parameters

$resource = Invoke-AzureRmResourceAction -ResourceGroupName $resourceGroupName -ResourceType Microsoft.Web/sites/config -ResourceName "$functionappName/appsettings" -Action list -ApiVersion 2015-08-01 -Force
$expectedSettingsInArmFormat = $armDeploymentParameters

$actualSettings = $resource.Properties

$keysToCheck = @('oAuthUrl', 'oAuthPassword', 'oAuthUsername', 'tradestoaborapi' )

AssertThat { Settings-Are-Equal -keysTocheck $keysToCheck -expectedValues $expectedSettingsInArmFormat -actualSettings $actualSettings  }

$expectedAccountKey = $expectedSettingsInArmFormat.tradeBlobstorageAccountKey.value
$expectedStorageName = $expectedSettingsInArmFormat.tradeBlobstorageName.value
AssertThat { $actualSettings.blobrawstorage_STORAGE -eq "DefaultEndpointsProtocol=https;AccountName=$expectedStorageName;AccountKey=$expectedAccountKey" }

exit 0