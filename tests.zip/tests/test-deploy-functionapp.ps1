$ErrorActionPreference = "Stop"
$RootDirectory = "$PSScriptRoot"
$DeployDirectory = "$RootDirectory\.."
$ResourcesDirectory = "$DeployDirectory\..\src\main\resources\"
# includes
."$RootDirectory\assert.ps1"
."$ResourcesDirectory\get-functionapp-name.ps1"
."$DeployDirectory\create-resource-group-if-not-exists.ps1"
."$DeployDirectory\get-resource-group-name.ps1"
."$DeployDirectory\get-resource-group-location.ps1"

Function FunctionAppExists
{
    Param(
        [Parameter(Mandatory=$True)]
        [string]$functionAppName
    )

    $queryResults = Find-AzureRmResource  -ResourceType "Microsoft.Web/sites" -ResourceNameEquals "$functionAppName"

    Write-Output $queryResultsMeasure

    $queryResultsMeasure = $queryResults | measure

    if($queryResultsMeasure.Count -eq 1){
        return $True
    }
    return $False
}

function Run-Deployment 
{
    . "$ResourcesDirectory\deploy.ps1" -azureAccountName $args[0] -azureAccountPassword $args[1] -armParametersFilePath $args[2]-functionCodeArchivePath $args[3] -azureSubscriptionId $args[4] -resourceGroupName $args[5] 
}

$dataDirectory = "$RootDirectory\data"

$azureAccountName = $env:AZURE_ACCOUNT_NAME
$azureAccountPassword = $env:AZURE_ACCOUNT_PASSWORD
$azurePasswordSecure = ConvertTo-SecureString $azureAccountPassword -AsPlainText -Force
$azureCredentials = New-Object System.Management.Automation.PSCredential($AzureAccountName, $AzurePasswordSecure)
$parametersFilePath = "$dataDirectory\script-parameters\valid-deploy.json"
$deploymentScriptParameters = (ConvertFrom-Json -InputObject (Gc $parametersFilePath -Raw))
$azureSubscriptionId = $deploymentScriptParameters.subscriptionID

Add-AzureRmAccount -Credential $azureCredentials -SubscriptionID $azureSubscriptionId

$armParametersFilePath = ("{0}\arm-parameters\{1}" -f $dataDirectory, $deploymentScriptParameters.armParametersFileName)
$functionappName = Get-Functionapp-Name -armParametersFilePath $armParametersFilePath

$functionCodeArchivePath = "$dataDirectory\$functionappName.zip"

$resourceGroupName = Get-Resource-Group-Name -RootDirectory $RootDirectory
$resourceGroupLocation = Get-Resource-Group-Location -RootDirectory $RootDirectory

Create-Resource-Group-If-Not-Exists -resourceGroupName $resourceGroupName -resourceGroupLocation $resourceGroupLocation

Run-Deployment $azureAccountName $azureAccountPassword $armParametersFilePath $functionCodeArchivePath $azureSubscriptionId $resourceGroupName

$functionAppExists = FunctionAppExists -functionAppName "$functionappName"

AssertThat { $functionAppExists -eq $True }

exit 0