
param(
 [Parameter(Mandatory=$True)]
 [string]
 $scriptToRun
)

$ErrorActionPreference = "Stop"

try
{
    ."$scriptToRun"
}
catch 
{
    Write-Host "Error: unhandled exception thrown" -foregroundColor "Red"
    $_.Exception | Write-Host -foregroundColor "Red"
    exit 1
}

if($LastExitCode -ne 0)
{
    Write-Host "Error: program exited with non-zero exit code" -foregroundColor "Red"
    exit 1
}
else
{
    Write-Host "OK" -foregroundColor "Green"
}
