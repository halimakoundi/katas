$ErrorActionPreference = "Stop"
$RootDirectory = "$PSScriptRoot"
$DeployDirectory = "$RootDirectory\..\"
$ResourcesDirectory = "$DeployDirectory\..\src\main\resources\"

# includes
Add-Type -AssemblyName System.IO.Compression.FileSystem

."$RootDirectory\assert.ps1"

."$DeployDirectory\unzip.ps1"
."$DeployDirectory\new-temporary-directory.ps1"
."$DeployDirectory\get-kudu-pscredentials.ps1"
."$DeployDirectory\get-resource-group-name.ps1"
."$DeployDirectory\get-resource-group-location.ps1"
."$DeployDirectory\create-resource-group-if-not-exists.ps1"
."$DeployDirectory\download-function-code.ps1"
."$ResourcesDirectory\get-functionapp-name.ps1"

function Function-Exists
{
    Param
    (
        [Parameter(Mandatory=$True)]
        [string]$resourceGroupName,
        [Parameter(Mandatory=$True)]
        [string]$functionappName
    )

    $downloadFilePath = [System.IO.Path]::GetTempFileName()

    Download-Function-Code -resourceGroupName $resourceGroupName -functionappName $functionappName -downloadFilePath $downloadFilePath

    $tempDirectory = New-TemporaryDirectory
    $unzippedFunctionappCodeFolder = "$tempDirectory\$functionappName-unzipped"
    Unzip "$downloadFilePath" "$unzippedFunctionappCodeFolder"

    $functionFolderExists = Test-Path "$unzippedFunctionappCodeFolder\$functionappName"
    $hostFileExists = Test-Path "$unzippedFunctionappCodeFolder\host.json"

    Remove-Item -Force -Path $downloadFilePath
    Remove-Item -Recurse -Force -Path $tempDirectory
    
    return $functionFolderExists -and $hostFileExists
}

function Run-Deployment 
{
    . "$ResourcesDirectory\deploy.ps1" -azureAccountName $args[0] -azureAccountPassword $args[1] -armParametersFilePath $args[2]-functionCodeArchivePath $args[3] -azureSubscriptionId $args[4] -resourceGroupName $args[5] 
}

$dataDirectory = "$RootDirectory\data"

$azureAccountName = $env:AZURE_ACCOUNT_NAME
$azureAccountPassword = $env:AZURE_ACCOUNT_PASSWORD
$azurePasswordSecure = ConvertTo-SecureString $azureAccountPassword -AsPlainText -Force
$azureCredentials = New-Object System.Management.Automation.PSCredential($AzureAccountName, $AzurePasswordSecure)
$parametersFilePath = "$dataDirectory\script-parameters\valid-deploy.json"
$deploymentScriptParameters = (ConvertFrom-Json -InputObject (Gc $parametersFilePath -Raw))
$azureSubscriptionId = $deploymentScriptParameters.subscriptionID

Add-AzureRmAccount -Credential $azureCredentials -SubscriptionID $azureSubscriptionId

$armParametersFilePath = ("{0}\arm-parameters\{1}" -f $dataDirectory, $deploymentScriptParameters.armParametersFileName)
$functionappName = Get-Functionapp-Name -armParametersFilePath $armParametersFilePath

$functionCodeArchivePath = "$dataDirectory\$functionappName.zip"

$resourceGroupName = Get-Resource-Group-Name -RootDirectory $RootDirectory
$resourceGroupLocation = Get-Resource-Group-Location -RootDirectory $RootDirectory

Create-Resource-Group-If-Not-Exists -resourceGroupName $resourceGroupName -resourceGroupLocation $resourceGroupLocation

Run-Deployment $azureAccountName $azureAccountPassword $armParametersFilePath $functionCodeArchivePath $azureSubscriptionId $resourceGroupName

$functionExists = Function-Exists -resourceGroupName $resourceGroupName -functionappName $functionappName

AssertThat { $functionExists -eq $True }

exit 0